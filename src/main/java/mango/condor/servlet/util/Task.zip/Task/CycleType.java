package mango.condor.servlet.util.Task;

/**
 * Copyright (c) 2011-2012 by 广州游爱 Inc.
 * @Author Create by 梁健荣
 * @Date 2015年4月16日 上午11:07:16
 * @Description 
 */
public enum CycleType {
	YEAR,MONTH,WEEK,DAY,HOUR,MINUTE,SECOND
}
